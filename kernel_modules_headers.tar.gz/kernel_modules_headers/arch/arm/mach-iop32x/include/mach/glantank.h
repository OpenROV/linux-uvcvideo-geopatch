/*
 * arch/arm/mach-iop32x/include/mach/glantank.h
 *
 * IO-Data GLAN Tank board registers
 */

#ifndef __GLANTANK_H
#define __GLANTANK_H

#define GLANTANK_UART		0xfe800000	/* UART */


#endif
