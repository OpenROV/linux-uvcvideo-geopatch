#ifndef __MACH_PXA300_H
#define __MACH_PXA300_H

#include <mach/pxa3xx.h>
#include <mach/mfp-pxa300.h>

#endif /* __MACH_PXA300_H */
