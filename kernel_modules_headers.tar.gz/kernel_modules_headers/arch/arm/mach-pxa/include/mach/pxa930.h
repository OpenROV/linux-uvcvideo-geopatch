#ifndef __MACH_PXA930_H
#define __MACH_PXA930_H

#include <mach/pxa3xx.h>
#include <mach/mfp-pxa930.h>

#endif /* __MACH_PXA930_H */
