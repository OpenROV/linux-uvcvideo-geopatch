#ifndef __MACH_PXA320_H
#define __MACH_PXA320_H

#include <mach/pxa3xx.h>
#include <mach/mfp-pxa320.h>

#endif /* __MACH_PXA320_H */

