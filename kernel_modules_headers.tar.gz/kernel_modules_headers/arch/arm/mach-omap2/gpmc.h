/*
 * General-Purpose Memory Controller for OMAP2
 *
 * Copyright (C) 2005-2006 Nokia Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * Do not include this file in any new code, this will get removed
 * once omap3 boots in device tree only mode.
 *
 */
#include <linux/omap-gpmc.h>
