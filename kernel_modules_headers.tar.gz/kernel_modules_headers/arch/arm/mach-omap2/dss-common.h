#ifndef __OMAP_DSS_COMMON__
#define __OMAP_DSS_COMMON__

/*
 * NOTE: this is a transitional file to help with DT adaptation.
 * This file will be removed when DSS supports DT.
 */

void __init omap4_panda_display_init_of(void);
void __init omap_4430sdp_display_init_of(void);
void __init omap3_igep2_display_init_of(void);

#endif
