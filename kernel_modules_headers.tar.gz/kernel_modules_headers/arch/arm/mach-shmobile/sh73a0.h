#ifndef __ASM_SH73A0_H__
#define __ASM_SH73A0_H__

extern struct smp_operations sh73a0_smp_ops;

#endif /* __ASM_SH73A0_H__ */
