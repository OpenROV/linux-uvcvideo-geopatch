#ifndef __ASM_R8A7790_H__
#define __ASM_R8A7790_H__

extern struct smp_operations r8a7790_smp_ops;

#endif /* __ASM_R8A7790_H__ */
